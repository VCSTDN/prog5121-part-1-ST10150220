
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ST10150220
 */
public class Login {
    private Map<String, String> registeredUsers; //the method used to store the firstname, lastname, username and password of the user together
    
    public static void main(String args []){
        Login login = new Login();    
        
        OUTER:
        while (true) { //Looped to allow the user to login after registering.
            Object[] options = {"Login", "Register", "Exit"};
            int choice = JOptionPane.showOptionDialog(null, "Would you like to Login or Register?", "Login or Register", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            switch (choice) {
                case JOptionPane.YES_OPTION:
                    {
                        String uName = JOptionPane.showInputDialog(null, "Please Enter Your Username");
                        String password = JOptionPane.showInputDialog(null,"Please Enter Password");
                        String loginStatus = login.returnLoginStatus(uName,password);
                        JOptionPane.showConfirmDialog(null, loginStatus);
                        break;
                    }
                case JOptionPane.NO_OPTION:
                    {
                        String fName = JOptionPane.showInputDialog(null, "Please Enter Your First Name");
                        String lName = JOptionPane.showInputDialog(null, "Please Enter Your Last Name");
                        String uName = JOptionPane.showInputDialog(null, "Please Enter Your Username");
                        String password = JOptionPane.showInputDialog(null, "Please Enter a Password");
                        String registrationMessage = login.registerUser(fName, lName, uName, password);
                        JOptionPane.showConfirmDialog(null, registrationMessage);
                        break;
                    }
                case JOptionPane.CANCEL_OPTION:
                case JOptionPane.CLOSED_OPTION:
                    break OUTER;
                default:
                    break;
            }
        }
    }
    
    public Login() {
        this.registeredUsers = new HashMap <>();
    }
    
    public String registerUser(String fName, String lName, String uName, String password){ //ensure that the username is correctly formatted and then returns the messages
        if  (!checkUserName(uName))
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        
        if  (!checkPassword(password))
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        
        registeredUsers.put(uName, password);
                return "Welcome " + fName + ", " + lName + " it is great to see you.";
    }
    
    public boolean loginUser (String uName, String password){ //checks if the login details entered match those which are stored
        return registeredUsers.containsKey(uName) && registeredUsers.get(uName).equals(password);
    }
    
    public String returnLoginStatus(String uName, String password){ //determines if the login was valid or not
        if(loginUser(uName,password))
            return "Login Succesful";
        else 
            return "Login failed. Please check Username or Password";
    }
    
    public boolean checkUserName(String uName){ //checks if the username is correctly formatted
        return uName.contains("_") && uName.length() <=5;
    }
    
    public boolean checkPassword(String password){ //checks if the password is correctly formatted
        if(password.length() <8)
            return false;
        
        boolean upperCase = false;
        boolean digit = false;
        boolean specialChar = false;
        boolean lowerCase = false;
        for (char c : password.toCharArray()){
            if (Character.isUpperCase(c))
                upperCase = true;
            else if (Character.isDigit(c))
                digit = true;
            else if (!Character.isLetterOrDigit(c))
                specialChar = true;
            else if (Character.isLowerCase(c))
                lowerCase = true;
        }
        return upperCase && digit && specialChar &&lowerCase;
    }
}
